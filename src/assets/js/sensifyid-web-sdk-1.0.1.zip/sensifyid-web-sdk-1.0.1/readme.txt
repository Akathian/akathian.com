SensifyID Web SDK v1.0.1

This package contains two files and one folder:

1. kinetic-sdk-1.0.1.min.js
	Minified version of the SensifyID SDK. (v 1.0.1)
	
2. quickstart v1
	This is a sample web application for the developers to see how the data was tracked locally. No data was sent to the server. No server configuration like appKey, appSecret, packageId is required.

3. quickstart v2
	This is a sample web application for the developers to use as a guide for integration of SensifyID SDK into a Web application. Server configuration like appKey, appSecret, packageId is required.

Please refer to the Quick Start guide for detailed instructions for integration of SDK into the web applications.